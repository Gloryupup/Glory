# coding:utf-8
from __future__ import print_function
from __future__ import division
from spider import read_data_from_mysql
from spider import save_news_to_mysql

# 本程序基于情感词典，并计算评论的情感

import jieba
import MySQLdb
from time import sleep

# 导入词典
stopwords = [line.strip().decode('utf-8') for line in open('stopwords.txt').readlines()]
PosDict = [line.strip().decode('utf-8', 'ignore') for line in open('positive.txt').readlines()]
NegDict = [line.strip().decode('utf-8', 'ignore') for line in open('negative.txt').readlines()]

PositiveDict = [u'好评',u'好看',u'炫酷',u'强',u'不错',u'好',u'终于到手',u' 最爱 萌萌哒',u'顶配',u'优惠',u'看中', u'档次',
u'酷',u'酷炫', u'真爱', u' 避震', u'点赞', u'赞', u'值',u'省油',u'拉风', u'炫',u'霸气', u'舒适', u'狠货',u'隔音',u'现场',u'飞碟',
u'最',u'保值',u'值得一看',u'值得',u'环保',u'精神',u'到手',u'爱不释手']
NegtiveDict = [u'好丑',u'假',u'差',u'情况',u'爆胎',u'毒 ',u'呼噜',u'大煞',u'全无',u'暴利',u'发响',u'掉漆','low',u'吐槽',u'熄火',
               u'断了',u'抖动',u'嗡嗡',u'尼玛',u'悲剧',u'差劲',u'毒',u'有毒']
NotDict = [u'不',u'并非', u'并不，'u'未',u'从未',u'没有']
keyword = [u'？','?',u'吗',u'么']
combine_word_neg = [u'油耗',u'声音',u'大',u'超大']
combine_word_pos = [u'小',u'超低',u'油耗',u'声音']
db_config={'host':'127.0.0.1','unix_socket':'/tmp/mysql.sock','user':'root','passwd':None,'charset':'utf8','db':'FreeTradeZone'}
# 读取数据并分词
def get_data():
    print("数据初始化")
    data =read_data_from_mysql(db_config, 'comment')
    #data = "我真的不喜欢这辆车"
    print("数据初始化完毕,共有" + str(len(data)) + "条数据需要处理")
    return data


def seg_dic():
    data = get_data()
    index = 0
    for x in data:
        print("情感分析当前进度" + str(index / len(data)))
        index += 1
        name = x['name']
        
        content = x['comment']
        if content is None:
            continue
        segmentation = jieba.cut(content)
        segmentation = list(segmentation)
        total_count = len(segmentation)
        pos_count = 0
        neg_count = 0
        j = 0
        m = 0
        # 对该条新闻的每个词进行处理
        while j < total_count:
            try:
                if segmentation[j] not in stopwords and segmentation[j] not in ['  ', ' '] and \
                    not segmentation[j].isdigit() and segmentation[j] is not None:
                    if segmentation[j] in PosDict or segmentation[j] in PositiveDict:
                        if segmentation[j-1] in NotDict:
                            neg_count += 1
                        else: pos_count +=1
                    elif segmentation[j] in NegDict or segmentation[j] in NegtiveDict:
                        if segmentation[j-1] in NotDict:
                            pos_count += 1
                        else: neg_count += 1
                    elif segmentation[j] in combine_word_neg and segmentation[j+1] in combine_word_neg:
                        neg_count += 1
                    elif segmentation[j] in combine_word_neg and segmentation[j+2] in combine_word_neg:
                        neg_count +=1
                    elif segmentation[j] in combine_word_pos and segmentation[j+1] in combine_word_pos:
                        pos_count += 1
                    elif segmentation[j] in combine_word_pos and segmentation[j+2] in combine_word_pos:
                        pos_count +=1
                    elif segmentation[j] in keyword:
                        neg_count = pos_count 
            except:
                m += 1
            j += 1
        if pos_count == neg_count:
            sentiment = 0
             
        elif pos_count > neg_count:
            sentiment = 1
            
        else: 
            sentiment = -1
        #conn=MySQLdb.connect(host="localhost", user="root", passwd="", db="car", charset="utf8")
        #cur = conn.cursor()
        #cur.execute('insert ignore into sentiment(name,sentiment) values(%s,%s)',(name,sentiment))
        #conn.commit()
        #cur.close();
        #conn.close();    
    return sentiment


def start():
    print("start")
    print("*" * 50)
    print("情感分析开始")
    relist = seg_dic()
    print("情感分析完毕，开始插入数据")
    for re_list in relist:
        save_news_to_mysql(re_list)
    print(re_list)
    print("数据插入完毕")
    print("*" * 50)
    print("end")


if __name__ == '__main__':
    start()