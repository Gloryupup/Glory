#-*-coding:utf-8 -*-
'''
Created on 2016年10月23日

@author: xiaozhi
'''
import MySQLdb

def read_data_from_mysql(db_config,table_name):
    conn = MySQLdb.connect(host="localhost", user="root", passwd="", db="car", charset="utf8")
    cur=conn.cursor(MySQLdb.cursors.DictCursor);
    cur.execute('select * from %s'%table_name)
    ret=cur.fetchall()
    cur.close()
    conn.close()
    return ret
def save_news_to_mysql(re_list):
    conn=MySQLdb.connect(host="localhost", user="root", passwd="", db="car", charset="utf8")
    cur = conn.cursor()
    cur.execute(cur.execute('insert ignore into car(sentiment) values(%s)',(re_list)))
    conn.commit()
    cur.close();
    conn.close();
            