# coding:utf-8
from __future__ import print_function
from __future__ import division
from spider import read_data_from_mysql
from spider import save_news_to_mysql

# 本程序基于情感词典，对评论舆情帖子统计积极消极词的个数，并计算帖子的情感

import jieba
import MySQLdb

# 导入词典
stopwords = [line.strip().decode('utf-8') for line in open('stopwords.txt').readlines()]
PosDict = [line.strip().decode('utf-8', 'ignore') for line in open('positive.txt').readlines()]
NegDict = [line.strip().decode('utf-8', 'ignore') for line in open('negative.txt').readlines()]

db_config={'host':'127.0.0.1','unix_socket':'/tmp/mysql.sock','user':'root','passwd':None,'charset':'utf8','db':'FreeTradeZone'}
# 读取数据并分词
def get_data():
    print("数据初始化")
    data = read_data_from_mysql(db_config, 'url_pattern')
    print("数据初始化完毕,共有" + str(len(data)) + "条数据需要处理")
    return data


def seg_dic():
    data = get_data()
    result_list = []
    index = 0
    for x in data:
        print("情感分析当前进度" + str(index / len(data)))
        index += 1
        news_id = x[0]
        content = x[1]
        if content is None:
            continue
        segmentation = jieba.cut(content)
        segmentation = list(segmentation)
        pos_count = 0
        neg_count = 0
        total_count = len(segmentation)
        j = 0
        m = 0
        # 对该条新闻的每个词进行处理
        while j < total_count:
            try:
                if segmentation[j] not in stopwords and segmentation[j] not in ['  ', ' '] and \
                        not segmentation[j].isdigit() and segmentation[j] is not None:
                    if segmentation[j] in PosDict:
                        pos_count += 1
                    elif segmentation[j] in NegDict:
                        neg_count += 1
            except:
                m += 1
            j += 1
        sentiment = 0.5
        if pos_count != 0 or neg_count != 0:
            # 此处仅计算正面词汇占比即可
            # sentiment = (pos_count - neg_count) / (pos_count + neg_count)
            sentiment = pos_count / (pos_count + neg_count)
            result_list.append((news_id, sentiment))
        else:
            result_list.append((news_id, sentiment))
    return result_list


def start():
    print("start")
    print("*" * 50)
    print("情感分析开始")
    re_list = seg_dic()
    print("情感分析完毕，开始插入数据")
    save_news_to_mysql(re_list)
    print("数据插入完毕")
    print("*" * 50)
    print("end")


if __name__ == '__main__':
    start()